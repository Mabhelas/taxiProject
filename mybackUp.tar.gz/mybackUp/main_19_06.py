mport os, os.path
import random
import string

import cherrypy

import json, urllib
from urllib import urlencode
import googlemaps
start = "90 Gwigwi Mrwebi St, Newtown, Johannesburg, 2113"
finish = "GO Health Club Northview,Northgate, Randburg, 2162"

url = 'http://maps.googleapis.com/maps/api/directions/json?%s' % urlencode((
            ('origin', start),
            ('destination', finish)
 ))
ur = urllib.urlopen(url)
result = json.load(ur)
myResult = ""
myResult1 = ""

for i in range (0, len (result['routes'][0]['legs'][0]['steps'])):
    j = result['routes'][0]['legs'][0]['steps'][i]['html_instructions'] 
    print j
    myResult = myResult + j + "\n";
    myResult = myResult + "<br>";

class StringGenerator(object):
    @cherrypy.expose
    def generate(self, start1, finish1):
	url = 'http://maps.googleapis.com/maps/api/directions/json?%s' % urlencode((
		    ('origin', start1),
		    ('destination', finish1)
	 ))
	ur = urllib.urlopen(url)
	result = json.load(ur)
	myResult1 = ""
	for i in range (0, len (result['routes'][0]['legs'][0]['steps'])):
	    j = result['routes'][0]['legs'][0]['steps'][i]['html_instructions'] 
	    print j
	    myResult1 = myResult1 + j + "\n";
	    myResult1 = myResult1 + "<br>";
	some_string = ''.join(myResult1)
	cherrypy.session['mystring'] = some_string
        return some_string

    @cherrypy.expose
    def display(self):
        return cherrypy.session['mystring']

    @cherrypy.expose
    def index(self):
        return """<html>
          <head>
	    <link href="/bootstrap/css/myBootstrap.css"/ rel="stylesheet">
          </head>
          <body>

			<nav role="navigation" class="nav">
	    <ul class="nav-items">
		<li class="nav-item">
		    <a href="/docs" class="nav-link"><span>Home</span></a>
		</li> 
		<li class="nav-item dropdown">
		    <a href="#" class="nav-link"><span>Products</span></a>
		    <nav class="submenu">
		        <ul class="submenu-items">
		            <li class="submenu-item"><a href="#" class="submenu-link">Product #1</a></li>
		            <li class="submenu-item"><a href="#" class="submenu-link">Product #2</a></li>
		            <li class="submenu-item"><a href="#" class="submenu-link">Product #3</a></li>
		        </ul>
		    </nav>
		</li> 
		<li class="nav-item">
		    <a id="displayText" href="javascript:toggle();" class="nav-link">Services</a>
		</li>
		<li class="nav-item">
		    <a href="#" class="nav-link"><span>Pricing</span></a>
		</li> 
		<li class="nav-item">
		    <a href="#" class="nav-link"><span>News</span></a>
		</li>
		<li class="nav-item dropdown">
		    <a href="#" class="nav-link"><span>More</span></a>
		    <nav class="submenu">
		        <ul class="submenu-items">
		            <li class="submenu-item"><a href="#" class="submenu-link">About</a></li>
		            <li class="submenu-item"><a href="#" class="submenu-link">Contact</a></li>
		            <li class="submenu-item"><hr class="submenu-seperator" /></li>
		            <li class="submenu-item"><a href="#" class="submenu-link">Support</a></li>
		            <li class="submenu-item"><a href="#" class="submenu-link">FAQs</a></li>
		            <li class="submenu-item"><a href="#" class="submenu-link">Careers</a></li>
		        </ul>
		    </nav>
		</li>  
	    </ul>
	</nav>

	
	<div id="toggleText" style="display: none">		  <h3>To Navigate from""" +start+ """ to """+finish+"""</h3>
		  <p>""" + myResult +"""</p>
		     <form method="get" action="generate">
		      <input type="text" value="8" name="start1" />
		      <input type="text" value="8" name="finish1" />
		      <button type="submit">Give it now!</button>
			<p>""" + myResult1 +"""</p>
		    </form></div>

		Some dynamic content<br/><a href="/docs">See docs</a>
            <form method="get" action="generate">
              <input type="text" value="8" name="start1" />
	      <input type="text" value="8" name="finish1" />
              <button type="submit">Give it now!</button>
            </form>

		 <div class="tab">
		  <button class="tablinks" onclick="openCity(event, 'London')">Home</button>
		  <button class="tablinks" onclick="openCity(event, 'Paris')">Find Destination</button>
		  <button class="tablinks" onclick="openCity(event, 'Tokyo')">About</button>
		  <button class="tablinks" onclick="openCity(event, 'Tokyo1')">Contacts</button>
		</div>

		<div id="London" class="tabcontent">
		  <h3>London</h3>
		  <p>This site helps you avoid being stolen, lol</p>
		</div>

		<div id="Paris" class="tabcontent">
		  <h3>To Navigate from""" +start+ """ to """+finish+"""</h3>
		  <p>""" + myResult +"""</p>
		     <form method="get" action="generate">
		      <input type="text" value="8" name="start1" />
		      <input type="text" value="8" name="finish1" />
		      <button type="submit">Give it now!</button>
			<p>""" + myResult1 +"""</p>
		    </form>
		</div>

		<div id="Tokyo" class="tabcontent">
		  <h3>Tokyo</h3>
		  <p>Tokyo is the capital of Japan.</p>
		</div> 
		<div id="Tokyo1" class="tabcontent">
		  <h3>Tokyo</h3>
		  <p>Contact us on : 0123456789.</p>
		</div>





		<script>
		function toggle() {

	var ele = document.getElementById("toggleText");

	var text = document.getElementById("displayText");

	if(ele.style.display == "block") {

    		ele.style.display = "none";

		text.innerHTML = "Services";

  	}

	else {

		ele.style.display = "block";

		text.innerHTML = "Services";

	}

} 



		[].slice.call(document.querySelectorAll('.dropdown .nav-link')).forEach(function(el){
		    el.addEventListener('click', onClick, false);
		});

		function onClick(e){
		    e.preventDefault();
		    var el = this.parentNode;
		    el.classList.contains('show-submenu') ? hideSubMenu(el) : showSubMenu(el);
		}

		function showSubMenu(el){
		    el.classList.add('show-submenu');
		    document.addEventListener('click', function onDocClick(e){
			e.preventDefault();
			if(el.contains(e.target)){
			    return;
			}
			document.removeEventListener('click', onDocClick);
			hideSubMenu(el);
		    });
		}

		function hideSubMenu(el){
		    el.classList.remove('show-submenu');
		}
		</script>
          </body>
        </html>"""







if __name__ == '__main__':
    path   = os.path.abspath(os.path.dirname(__file__))
    conf = {
        '/': {
            'tools.sessions.on': True,
            'tools.staticdir.root': os.path.abspath(os.getcwd())
        },
        '/bootstrap': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': '/usr/lib/python2.7/dist-packages/cherrypy/tutorial/bootstrap'
        },
	  '/docs' : {
	    'tools.staticdir.on'    : True,
	    'tools.staticdir.dir'   : os.path.join(path, 'docs'),
	    'tools.staticdir.index' : 'index.html',
	    'tools.gzip.on'         : True  
	  }

    }
    cherrypy.quickstart(StringGenerator(), '/', conf)

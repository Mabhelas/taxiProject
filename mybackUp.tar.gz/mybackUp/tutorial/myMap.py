import json, urllib
from urllib import urlencode
import googlemaps
start = "Maple Dr, Northwold, Randburg, 2188"
finish = "Northgate, Randburg, 2162"

url = 'http://maps.googleapis.com/maps/api/directions/json?%s' % urlencode((
            ('origin', start),
            ('destination', finish)
 ))
ur = urllib.urlopen(url)
result = json.load(ur)

for i in range (0, len (result['routes'][0]['legs'][0]['steps'])):
    j = result['routes'][0]['legs'][0]['steps'][i]['html_instructions'] 
    print j

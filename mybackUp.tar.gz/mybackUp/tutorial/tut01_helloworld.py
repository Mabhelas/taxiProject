#!/usr/bin/env python
# -*- coding: utf-8 -*-


import os

import cherrypy
from os.path import abspath
import cpcgiserver
import sys
sys.path.insert(0,'parser/usr/lib/python2.7/dist-packages/cherrypy/tutorial')
import argparse


parser = argparse.ArgumentParser()

# Add more options if you like
parser.add_argument("-f", "--file", dest="target",
                    help="write report to FILE", metavar="FILE")
parser.add_argument("-q", "--quiet",
                    action="store_false", dest="verbose", default=True,
                    help="don't print status messages to stdout")
args = parser.parse_args()

SITE_ROOT = '/usr/lib/python2.7/dist-packages/cherrypy/tutorial'
path   = os.path.abspath(os.path.dirname(__file__))
config = {
  'global' : {
    'server.socket_host' : '127.0.0.1',
    'server.socket_port' : 8080,
    'server.thread_pool' : 4,
    'log.error_file'	 : 'Web.log',
    'log.access_file'	 : 'Access.log',
  },
  "/": {
            "tools.cgiserver.on": True,
            "tools.cgiserver.dir": SITE_ROOT,
            "tools.cgiserver.base_url": "/",
            "tools.cgiserver.handlers": {".php": "/usr/lib/python2.7/dist-packages/cherrypy/tutorial/shapely"},
        },
        '/shapely': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': abspath('./shapely') # staticdir needs an absolute path
            },
}

def app():
    return file("shapely/comments.php")
app.exposed = True


cherrypy.tree.mount(app, '/', config)
cherrypy.log("log end")


if __name__ == '__main__':
  cherrypy.engine.start()
  cherrypy.engine.block()
  cherrypy.log("main end")

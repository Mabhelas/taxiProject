import os
import random
import string

import cherrypy

import json, urllib
from urllib import urlencode
import googlemaps
start = "90 Gwigwi Mrwebi St, Newtown, Johannesburg, 2113"
finish = "GO Health Club Northview,Northgate, Randburg, 2162"

url = 'http://maps.googleapis.com/maps/api/directions/json?%s' % urlencode((
            ('origin', start),
            ('destination', finish)
 ))
ur = urllib.urlopen(url)
result = json.load(ur)
myResult = ""
myResult1 = ""

for i in range (0, len (result['routes'][0]['legs'][0]['steps'])):
    j = result['routes'][0]['legs'][0]['steps'][i]['html_instructions'] 
    print j
    myResult = myResult + j + "\n";
    myResult = myResult + "<br>";

class StringGenerator(object):
    @cherrypy.expose
    def generate(self, start1, finish1):
	url = 'http://maps.googleapis.com/maps/api/directions/json?%s' % urlencode((
		    ('origin', start1),
		    ('destination', finish1)
	 ))
	ur = urllib.urlopen(url)
	result = json.load(ur)
	myResult1 = ""
	for i in range (0, len (result['routes'][0]['legs'][0]['steps'])):
	    j = result['routes'][0]['legs'][0]['steps'][i]['html_instructions'] 
	    print j
	    myResult1 = myResult1 + j + "\n";
	    myResult1 = myResult1 + "<br>";
	some_string = ''.join(myResult1)
	cherrypy.session['mystring'] = some_string
        return some_string

    @cherrypy.expose
    def display(self):
        return cherrypy.session['mystring']

    @cherrypy.expose
    def index(self):
        return """<html>
          <head>
	    <link href="/bootstrap/css/myBootstrap.css"/ rel="stylesheet">
          </head>
          <body background="/bootstrap/img/taxiRank2.jpg">

			<nav role="navigation" class="nav">
	    <ul class="nav-items">
		<li class="nav-item">
		    <a href="/docs" class="nav-link"><span>Home</span></a>
		</li> 
		<li class="nav-item dropdown">
		    <a href="#" class="nav-link"><span>Find destination</span></a>
		    <nav class="submenu">
		        <ul class="submenu-items">
		            <li class="submenu-item"><a href="/docs/a.html" class="submenu-link">Map</a></li>
		            <li class="submenu-item"><a href="/docs/findTaxiRank.html" class="submenu-link">Navigate</a></li>
		        </ul>
		    </nav>
		</li>

		<li class="nav-item">
		    <a href="/docs/a.html" class="nav-link"><span>Map</span></a>
		</li>
		<li class="nav-item dropdown">
		    <a href="#" class="nav-link"><span>Help center</span></a>
		    <nav class="submenu">
		        <ul class="submenu-items">
		            <li class="submenu-item"><a href="www.google.com" class="submenu-link">Lost and found</a></li>
		            <li class="submenu-item"><a href="/docs/reportDriver.html" class="submenu-link">Report driver</a></li>
		        </ul>
		    </nav>
		</li>  
	    </ul>
	</nav>

	
	<div id="toggleText" style="display: none">		  <h3>To Navigate from""" +start+ """ to """+finish+"""</h3>
		  <p>""" + myResult +"""</p>
		     <form method="get" action="generate">
		      <input type="text" value="8" name="start1" />
		      <input type="text" value="8" name="finish1" />
		      <button type="submit">Give it now!</button>
			<p>""" + myResult1 +"""</p>
		    </form></div>

	<div id="toggleText1" style="display: none">		  <h3>To Navigate from""" +start+ """ to """+finish+"""</h3>
		  <p>""" + myResult +"""</p>
		     <form method="get" action="generate">
		      <input type="text" value="8" name="start1" />
		      <input type="text" value="8" name="finish1" />
		      <button type="submit">Give it now!</button>
			<p>""" + myResult1 +"""</p>
			SECOND TEST!!!!!!
		    </form></div>

		Description [with signs] <br><br>

		Easily find : <br>
			<a href="/docs">Routes</a> <br><br>
			<a href="/docs">Lost and found</a> <br><br>
			<a href="/docs">Report driver</a> <br><br>
		Some dynamic content<br/><a href="/docs">See docs</a>
            <form method="get" action="generate">
              <input type="text" value="8" name="start1" />
	      <input type="text" value="8" name="finish1" />
              <button type="submit">Give it now!</button>
            </form>


		<script>
		var ele = document.getElementById("toggleText");
		var ele1 = document.getElementById("toggleText1");
		function toggle() {


	var text = document.getElementById("displayText");

	if(ele.style.display == "block") {

    		ele.style.display = "block";

		text.innerHTML = "Services";

  	}

	else {
		ele1.style.display = "none";
		ele.style.display = "block";

		text.innerHTML = "Services";

	}

} 


		function toggle1() {

	

	var text = document.getElementById("displayText1");

	if(ele1.style.display == "block") {

    		ele1.style.display = "block";

		text.innerHTML = "Pricing";

  	}

	else {
		ele.style.display = "none";

		ele1.style.display = "block";

		text.innerHTML = "Pricing";

	}

} 


		[].slice.call(document.querySelectorAll('.dropdown .nav-link')).forEach(function(el){
		    el.addEventListener('click', onClick, false);
		});

		function onClick(e){
		    e.preventDefault();
		    var el = this.parentNode;
		    el.classList.contains('show-submenu') ? hideSubMenu(el) : showSubMenu(el);
		}

		function showSubMenu(el){
		    el.classList.add('show-submenu');
		    document.addEventListener('click', function onDocClick(e){
			e.preventDefault();
			if(el.contains(e.target)){
			    return;
			}
			document.removeEventListener('click', onDocClick);
			hideSubMenu(el);
		    });
		}

		function hideSubMenu(el){
		    el.classList.remove('show-submenu');
		}
		</script>
          </body>
        </html>"""







if __name__ == '__main__':
    file_path = os.getcwd().replace("\\", "/")
    path   = os.path.abspath(os.path.dirname(__file__))
    conf = {
        '/': {
            'tools.sessions.on': True,
            'tools.staticdir.root': os.path.abspath(os.getcwd())
        },
        '/bootstrap': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': '/usr/lib/python2.7/dist-packages/cherrypy/tutorial/bootstrap'
        },
	  '/docs' : {
	    'tools.staticdir.on'    : True,
	    'tools.staticdir.dir'   : os.path.join(path, 'docs'),
	    'tools.staticdir.index' : 'index.html',
	    'tools.gzip.on'         : True  
	  }

    }
    cherrypy.quickstart(StringGenerator(), '/', conf)
